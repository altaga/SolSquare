import * as web3 from "@solana/web3.js";
import { deserialize } from "borsh";
import { Buffer } from "buffer";// Manually initialize variables that are automatically defined in Playground
const PROGRAM_ID = new web3.PublicKey("7GTHRrqPjABFdUPmdPAmiaqdhJ162cAg1mTXTY5z9Y7D");
const connection = new web3.Connection("https://api.devnet.solana.com", "confirmed");
const wallet = { keypair: web3.Keypair.generate() };


import {
  PublicKey,
} from "@solana/web3.js";

class Assignable {
  constructor(properties) {
    Object.keys(properties).map((key) => {
      return (this[key] = properties[key]);
    });
  }
}

class Payload extends Assignable { }

const memorySchema = new Map([
  [
    Payload,
    {
      kind: "struct",
      fields: [
        ["content", "String"],
        ["owner", "String"],
        ["timestamp", "u32"]
      ],
    },
  ],
]);

// Check

// program id
const programId = PROGRAM_ID

// connection
const connection = connection

// setup fee payer
const feePayer = wallet.keypair

const accounts = await connection.getProgramAccounts(programId,
  {
    filters: [
      {
        dataSize: 184, // number of bytes
      }
    ],
  })

let tweets = accounts.map((tweet) => deserialize(memorySchema, Payload, tweet.account.data));
tweets = tweets.map((tweet) => {
  return {
    ...tweet,
    content: tweet.content.replaceAll("#","")
  }
})

console.log(tweets)
